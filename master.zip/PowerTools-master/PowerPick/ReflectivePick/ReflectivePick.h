
HINSTANCE hAppInstance;