# PowerTools Is Now Deprecated!

### PowerView and PowerUp have moved to the [PowerSploit repository](https://github.com/PowerShellMafia/PowerSploit/) under ./Recon/ and ./Privesc/ respectively.

### PowerPick will move repository locations shortly back to its original home.

### PewPewPew is no longer supported.

No pull requests will be accepted and no issues will be answered, however the repository code will be left up for the time being.

Originally developed by [@harmj0y](https://twitter.com/harmj0y) and [@sixdub](https://twitter.com/sixdub)
