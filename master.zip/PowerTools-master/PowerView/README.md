# PowerTools Is Now Depreciated

## PowerUp have moved to the [PowerSploit repository](https://github.com/PowerShellMafia/PowerSploit/tree/master/Recon) under ./Recon/ .
